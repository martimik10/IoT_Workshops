#include <Arduino.h>

#define PRINT(var) Serial.print(#var ":\t"); Serial.print(var); Serial.print('\t')
#define PRINTLN(var) Serial.print(#var ":\t"); Serial.println(var)
#define BUTTON1 8
#define BUTTON2 9
#define LED 5
#define PATTERN 2 //USER ADJUSTABLE 1 or 2

void pattern1(bool Button1_read, bool Button2_read);
void pattern2(bool Button1_read, bool Button2_read);


void setup(){
    Serial.begin(9600);
    pinMode(BUTTON1, INPUT_PULLUP);
    pinMode(BUTTON2, INPUT_PULLUP);
    pinMode(LED, OUTPUT);
}

bool flag = LOW; //Flag for first button
bool flag2 = LOW; //Flag for second button
bool flag3 = LOW; //Flag for both pressed
bool LED_on = LOW;


void loop(){
    //if chosen PATTERN 1: no matter what switch is pressed, the LED changes state (from on to off, or from off to on)
    //if chosen PATTERN 2: when both switches are pressed at the same time, the LED changes state (from on to off, or from off to on)

    bool Button1_read = digitalRead(BUTTON1);
    bool Button2_read = digitalRead(BUTTON2);

    if (PATTERN == 2){
        pattern2(Button1_read, Button2_read);
    }
    else{
        pattern1(Button1_read, Button2_read);
    }

    PRINT(Button1_read);
    PRINT(Button2_read);
    PRINTLN(LED_on);
}



void pattern1(bool Button1_read, bool Button2_read){
    if (Button1_read != flag) {
        flag = Button1_read;
        if (Button1_read == LOW) {
            LED_on = (LED_on == HIGH) ? LOW: HIGH; //one-liner toggle: (condition) ? if true use LOW : if false use HIGH
            digitalWrite(LED, LED_on);
        }
    }

    else if (Button2_read != flag2) {
        flag2 = Button2_read;
        if (Button2_read == LOW) {
            LED_on = (LED_on == HIGH) ? LOW: HIGH;
            digitalWrite(LED, LED_on);
        }
    }  
}

void pattern2(bool Button1_read, bool Button2_read){
    if ((Button1_read || Button2_read) != flag3) { // or gives 0 if both pressed, 1 otherwise
        flag3 = (Button1_read || Button2_read);
        if ((Button1_read || Button2_read) == LOW) {
            LED_on = (LED_on == HIGH) ? LOW: HIGH;
            digitalWrite(LED, LED_on);
        }
    }  
}
